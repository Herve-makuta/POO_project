import unittest
from models.unit import Unit
from models.landlord import Landlord
from models.lease_contract import LeaseContract, TypeBail
from models.unit_assignment import UnitAssignment
from datetime import date, timedelta

class TestUnit(unittest.TestCase):
    def test_unit_creation(self):
        unit = Unit(1, "Unit A", "République Démocratique du Congo", "Kinshasa", "Standard", 3, 2, True, True)
        self.assertEqual(unit.nom, "Unit A")
        self.assertEqual(unit.pays, "République Démocratique du Congo")
        self.assertTrue(unit.est_valide())

    def test_invalid_unit(self):
        unit = Unit(2, "Unit B", None, "Kinshasa", "Standard", 0, 2, True, True)
        self.assertFalse(unit.est_valide())

class TestLeaseContract(unittest.TestCase):
    def test_lease_contract_id_generation(self):
        landlord = Landlord(1, "Landlord A")
        contract = LeaseContract(1000, landlord, TypeBail.LONG_TERM, "Notes")
        self.assertEqual(contract.generer_id(), "LEACON-1000")

class TestUnitAssignment(unittest.TestCase):
    def test_assignment_total_amount(self):
        unit = Unit(1, "Unit A", "République Démocratique du Congo", "Kinshasa", "Standard", 3, 2, True, True)
        contract = LeaseContract(1000, None, TypeBail.LONG_TERM, "Notes")
        assignment = UnitAssignment(1, unit, contract, 500, date.today(), date.today() + timedelta(days=60))
        self.assertEqual(assignment.calculer_montant_total(), 1000)

    def test_assignment_current_status(self):
        unit = Unit(1, "Unit A", "République Démocratique du Congo", "Kinshasa", "Standard", 3, 2, True, True)
        contract = LeaseContract(1000, None, TypeBail.LONG_TERM, "Notes")
        assignment = UnitAssignment(1, unit, contract, 500, date.today() - timedelta(days=30), date.today() + timedelta(days=30))
        self.assertTrue(assignment.est_en_cours())

if __name__ == '__main__':
    unittest.main()