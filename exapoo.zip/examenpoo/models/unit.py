class Unit:
    def __init__(self, id, nom, pays, etat_province, classe, nb_chambres, nb_salles_de_bain, wifi, climatisation):
        self.id = id
        self.nom = nom
        self.pays = pays
        self.etat_province = etat_province
        self.classe = classe
        self.nb_chambres = nb_chambres
        self.nb_salles_de_bain = nb_salles_de_bain
        self.wifi = wifi
        self.climatisation = climatisation

    def afficher_details(self):
        return (f"Unit {self.nom}: {self.nb_chambres} chambres, "
                f"{self.nb_salles_de_bain} salles de bain, Pays: {self.pays}")

    def est_valide(self):
        return (self.pays is not None and 
                self.etat_province is not None and 
                self.nb_chambres > 0 and 
                self.nb_salles_de_bain > 0)