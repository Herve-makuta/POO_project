class Landlord:
    def __init__(self, id, nom):
        self.id = id
        self.nom = nom
        self.liste_unites = []
        self.liste_contrats = []

    def ajouter_unite(self, unit):
        if unit.est_valide():
            self.liste_unites.append(unit)

    def ajouter_contrat(self, contrat):
        self.liste_contrats.append(contrat)