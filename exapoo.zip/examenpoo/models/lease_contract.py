from enum import Enum

class TypeBail(Enum):
    SHORT_TERM = "Short-Term"
    LONG_TERM = "Long-Term"
    STUDENT = "Student"

class LeaseContract:
    def __init__(self, id, landlord, type_bail, notes):
        self.id = id
        self.landlord = landlord
        self.type_bail = type_bail
        self.notes = notes
        self.liste_affectations = []

    def ajouter_affectation(self, affectation):
        if affectation.est_en_cours():
            self.liste_affectations.append(affectation)

    def generer_id(self):
        return f"LEACON-{self.id:04d}"