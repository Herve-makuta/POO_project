from datetime import date, timedelta

class UnitAssignment:
    def __init__(self, id, unit, contrat, loyer_mensuel, date_debut, date_fin):
        self.id = id
        self.unit = unit
        self.contrat = contrat
        self.loyer_mensuel = loyer_mensuel
        self.date_debut = date_debut
        self.date_fin = date_fin
        self.date_prochaine_facture = date_debut
        self.factures_precedentes = []

    def calculer_montant_total(self):
        duree = (self.date_fin - self.date_debut).days // 30
        return self.loyer_mensuel * duree

    def est_en_cours(self):
        return self.date_debut <= date.today() <= self.date_fin

    def calculer_facture_estimee(self):
        if self.factures_precedentes:
            derniere_facture = self.factures_precedentes[-1]
            prochaine_date = derniere_facture + timedelta(days=30)
            self.date_prochaine_facture = prochaine_date
        else:
            self.date_prochaine_facture += timedelta(days=30)
        return self.loyer_mensuel