class Utilisateur:
    def __init__(self, id, nom, role):
        self.id = id
        self.nom = nom
        self.role = role

    def has_permission(self, action):
        raise NotImplementedError("This method should be overridden in subclasses")

    def afficher_profil(self):
        return f"Utilisateur: {self.nom}, Rôle: {self.role}"

class LeaseClerk(Utilisateur):
    def has_permission(self, action):
        return action in ['create_unit', 'create_assignment']

class LeaseManager(Utilisateur):
    def has_permission(self, action):
        return action in ['create_unit', 'modify_assignment']

class LeaseManagerSupervisor(Utilisateur):
    def has_permission(self, action):
        return True