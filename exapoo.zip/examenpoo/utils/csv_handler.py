import csv

def sauvegarder_donnees_en_csv(filename, data):
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["ID", "Nom", "Pays", "Etat/Province", "Classe", "Chambres", "Salles de Bain"])
        for unit in data:
            writer.writerow([unit.id, unit.nom, unit.pays, 
                             unit.etat_province, unit.classe, 
                             unit.nb_chambres, unit.nb_salles_de_bain])