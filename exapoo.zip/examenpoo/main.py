from models.unit import Unit
from models.landlord import Landlord
from models.lease_contract import LeaseContract, TypeBail
from models.unit_assignment import UnitAssignment
from models.user import LeaseClerk, LeaseManager, LeaseManagerSupervisor
from utils.csv_handler import sauvegarder_donnees_en_csv

def afficher_menu():
    print("Bienvenue dans le système de gestion de baux UBuyIRent")
    print("1. Créer une unité")
    print("2. Créer une affectation")
    print("3. Afficher les détails d'une unité")
    print("4. Générer un rapport CSV")
    print("5. Quitter")

def main():
    clerk = LeaseClerk(1, "John Doe", "LeaseClerk")
    units = []

    while True:
        afficher_menu()
        choix = input("Choisissez une option: ")
        if choix == '1' and clerk.has_permission('create_unit'):
            # Logique de création d'une unité
            unit = Unit(1, "Unit A", "République Démocratique du Congo", "Kinshasa", "Standard", 3, 2, True, True)
            if unit.est_valide():
                units.append(unit)
                print("Unité créée avec succès!")
            else:
                print("Erreur : Unité invalide.")

        elif choix == '2' and clerk.has_permission('create_assignment'):
            # Logique de création d'une affectation
            print("Fonctionnalité de création d'affectation")

        elif choix == '3':
            # Logique d'affichage des détails
            for unit in units:
                print(unit.afficher_details())

        elif choix == '4':
            # Générer un rapport CSV
            sauvegarder_donnees_en_csv("rapport_units.csv", units)
            print("Rapport CSV généré avec succès!")

        elif choix == '5':
            print("Au revoir!")
            break

        else:
            print("Option invalide, veuillez réessayer.")

if __name__ == "__main__":
    main()

